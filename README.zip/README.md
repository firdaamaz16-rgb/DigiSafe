# DIGISAFE — Website demo

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka folder `digisafe_website`.
3. Buka `index.html` di browser, atau buka folder melalui VS Code dan gunakan ekstensi Live Server.

## Fitur yang sudah dibuat
- Landing page responsif mengikuti referensi visual.
- Navigasi Beranda, InfoCheck, ThreatScan, dan Digital Learning Hub.
- InfoCheck berupa panduan pemeriksaan informasi.
- ThreatScan berbasis kata kunci untuk tanda risiko umum.
- Kuis interaktif 5 soal dan skor.
- Materi singkat privasi, cyberbullying, dan berpikir kritis.
- Modal masuk sebagai tampilan demo.

## Catatan
Ini prototype front-end. InfoCheck belum terhubung ke sumber berita/fact-checking live, ThreatScan bukan pemindai keamanan profesional, dan form masuk belum memiliki backend/database. Jangan gunakan data asli atau kata sandi sungguhan pada demo.
